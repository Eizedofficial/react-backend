<?php

R::setup('mysql:host=localhost;dbname=shop',
    'root', 'root');
