<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/react-backend/vendor/autoload.php';
header('Content-Type: application/json');

$games = R::findAll('games');
foreach ($games as &$game) {
    $game['id'] = (int)$game['id'];
    $game['price'] = (int)$game['price'];
    $game['imagePath'] = $_SERVER['DOCUMENT_ROOT'] . '/react-backend/images/' . $game['image_name'];
    unset($game['image_name']);
}

echo json_encode($games);
