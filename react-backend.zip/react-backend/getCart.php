<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/react-backend/vendor/autoload.php';
require_once 'functions.php';
header('Content-Type: application/json');

if (empty($_GET['userId'])) {
    die(json_encode('Неправильный формат входных данных'));
}

echo json_encode(['totalSum' => getCart($_GET['userId']) ?? 0]);