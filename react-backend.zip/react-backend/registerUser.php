<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/react-backend/vendor/autoload.php';
header('Content-Type: application/json');

$user = R::dispense('users');
$id = R::store($user);

echo json_encode(['id' => $id]);
