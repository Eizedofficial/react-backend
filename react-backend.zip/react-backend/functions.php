<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/react-backend/vendor/autoload.php';

function getCart($userID) {
    return R::getCell(
        "SELECT
            SUM(quantity * price) AS total_sum 
        FROM 
            cart as c
        LEFT JOIN
            games as g
        ON
            g.id = c.game_id
        WHERE
            c.user_id = '$userID'
    "
    );
}