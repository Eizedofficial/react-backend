<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/react-backend/vendor/autoload.php';
header('Content-Type: application/json');
$arResponse = ['success' => true];

if (empty($_GET['userId']) || empty($_GET['gameId'])) {
    die(json_encode('Неправильный формат входных данных'));
}

$gameID = $_GET['gameId'];
$userID = $_GET['userId'];

$cart = R::findOne('cart', "WHERE game_id = '$gameID' AND user_id = '$userID'");
if (!is_null($cart)) {
    $cart['quantity'] = is_null($cart['quantity']) ? 1 : $cart['quantity'] + 1;
    $cart['user_id'] = $userID;
    $cart['game_id'] = $gameID;

    R::trash($cart);
}

$totalSum = getCart($userID);
$arResponse['totalSum'] = (int)$totalSum;

echo json_encode($arResponse);
