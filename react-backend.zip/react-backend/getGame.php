<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/react-backend/vendor/autoload.php';
header('Content-Type: application/json');

if (empty($_GET['id'])) {
    die(json_encode('Неправильный формат id'));
}

$gameId = $_GET['id'];
$game = R::load('games', $gameId);
if ($game['id'] == 0) {
    die(json_encode('Игра не найдена'));
}

$game['id'] = (int)$game['id'];
$game['price'] = (int)$game['price'];
$game['imagePath'] = $_SERVER['DOCUMENT_ROOT'] . '/react-backend/images/' . $game['image_name'];
unset($game['image_name']);

echo json_encode($game);